//
//  CustomisedCell.swift
//  Day4IosProgramming
//
//  Created by Guneet Singh Lamba on 23/02/18.
//  Copyright © 2018 Guneet Singh Lamba. All rights reserved.
//

import UIKit

class CustomisedCell: UITableViewCell {

    @IBOutlet weak var FoodName: UILabel!
    @IBOutlet weak var Regularlabel: UILabel!
    @IBOutlet weak var RegularPrice: UILabel!
    @IBOutlet weak var SpecialPrice: UILabel!
    @IBOutlet weak var SpecialPricevalue: UILabel!
    
    func show(isSpecial:Bool,price: Double) {
        if !isSpecial {
            SpecialPrice.text = ""
            SpecialPricevalue.text = ""
            RegularPrice.text = "$\(price)"
            contentView.backgroundColor = UIColor.white
        }
        else {
            SpecialPrice.text = "Special"
            SpecialPrice.textColor = UIColor.red
            RegularPrice.text = "$\(price)"
            SpecialPricevalue.text = "$\(price - 5)"
            contentView.backgroundColor = UIColor.cyan
        }
}
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
