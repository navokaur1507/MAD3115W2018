//
//  ViewController.swift
//  Day 2 ios
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    
    @IBOutlet weak var txtPassword: UITextField!
    
    
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



    
    //@IBOutlet weak var LoginAction: UINavigationItem!
  
    
    @IBAction func LoginAction(_ sender: UIBarButtonItem) {
        let Email = txtEmail.text
        let password = txtPassword.text
        if (Email == "test" && password == "test") {
            
            let inforAlert = UIAlertController(title: "Login Successful", message: "you are authenticated:", preferredStyle: .alert)
            
            inforAlert.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            
            self.present(inforAlert,animated: true, completion: nil)
        }
    }
    
   
    
    
   
   
    @IBAction func RegisterTim(_ sender: UIBarButtonItem) {
        func RegisterTim(_ sender: UIBarButtonItem) {
        }
        let regiserSB: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let regiserVC = regiserSB.instantiateViewController(withIdentifier: "RegistrationScreen")
        
        // self.present(regiserVC, animated: true, completion: nil)
        
        navigationController?.pushViewController(regiserVC, animated: true)
    }
}

    

