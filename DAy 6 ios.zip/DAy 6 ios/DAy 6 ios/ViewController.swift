//
//  ViewController.swift
//  DAy 6 ios
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtcarplate: UITextField!
    @IBOutlet weak var txtcarcolor: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnnewaction(_ sender: Any) {
        self.writePropertyList()
    }
    
    
    @IBAction func btnlistAllAction(_ sender: Any) {
        let listSB = UIStoryboard(name: "Main", bundle: nil)
        let listVC = listSB.instantiateViewController(withIdentifier: "CarListScreen")
        self.navigationController?.pushViewController(listVC, animated: true)
    }
    
    
func writePropertyList(){
    let mycar = NSMutableDictionary()
    mycar["carPlate"] = self.txtcarplate.text
    mycar["carColor"] = self.txtcarcolor.text
  if let plistPath = Bundle.main.path(forResource: "cars", ofType: "plist"){
        let carsplist = NSMutableArray(contentsOfFile: plistPath)
        carsplist?.add(mycar)
        if( carsplist?.write(toFile: plistPath, atomically: true))!{
            print("carslist: \(String(describing: carsplist))")
        }
        
    }else{
        print("Unable to locate plist file")
    }
    
}



}
