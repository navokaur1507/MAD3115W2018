//
//  RegistervcViewController.swift
//  Day 3 ios
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegistervcViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return self.citylist.count
    }
    
    func pickerView(_ pickerview: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.citylist[row]
    }
    
    @IBOutlet weak var txtname: UITextField!
    
    @IBOutlet weak var txtpwd: UITextField!
    
    @IBOutlet weak var datepicker: UIDatePicker!
    
    @IBOutlet weak var citypicker: UIPickerView!
    
    @IBOutlet weak var postalcode: UITextField!
    
    @IBOutlet weak var txtemail: UITextField!
    
    @IBOutlet weak var dateofbirth: UIDatePicker!
    
    @IBOutlet weak var contactnumber: UITextField!
    
    var citylist: [String] = ["Vancouver", "Ottawa", "Toronto", "Calgory", "windsor", "Ajex", "Pickering", "Admenton", "Jasper", "Qubc", "Albrta", "British Columbia", "Montreal"]
    var selectedcityindex: Int = 0

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //add data pickr
        self.citypicker.delegate = self
        self.citypicker.dataSource = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc private func displayvalues(){
        self.selectedcityindex = self.citypicker.selectedRow(inComponent: 0)
        
        let allData: String = "\(self.txtname.text!)\n\(self.contactnumber.text!)\n\(self.dateofbirth.date)\n\(self.citylist[selectedcityindex])\n\(self.postalcode.text!)\n\(self.txtpwd.text!)\n\(self.txtemail.text!)"
    
       // if Customer.addCustomer(cust: newCustomer){
            //transfer to next screen
            
            //get an instance of storyboard
           // let homeSB: UIStoryboard =
    
    //lt infoalert = UIAlertController(title: "Verify your details", messege: alldata, preferredStyle: .alert)
    
    //Action sheet
        let infoAlert = UIAlertController(title: "Verify your details", message: allData, preferredStyle: .actionSheet)
    
    infoAlert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
    infoAlert.addAction(UIAlertAction(title: "Confirm", style.displayWelcomScreen()}))
    
    self.present(infoAlert, animated: true, completion: nil)
}
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

