//
//  ViewController.swift
//  day6IOS
//
//  Created by MacStudent on 2018-02-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var moodsSegment: UISegmentedControl!
    @IBOutlet weak var imgMood: UIImageView!
    @IBOutlet weak var myStepper: UIStepper!
    @IBOutlet weak var SliderValue: UISlider!
    @IBOutlet weak var LbStepperValue: UILabel!
    @IBOutlet weak var LblSliderValue: UILabel!
    @IBOutlet weak var LblProgessView: UILabel!
    @IBOutlet weak var myProgressView: UIButton!
    @IBOutlet weak var ProgessView: UIProgressView!
    
    var moodimages: [UIImage] = [UIImage(named : "jack.jpg")!, UIImage(named : "tommy.jpg")!, UIImage(named : "jerry.jpg")!]
    
    var progressTimer = Timer()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ProgessView.progress = 0.0
        LblProgessView.text = "\(Int(ProgessView.progress*100))%"
        self.progressTimer = Timer.scheduledTimer(timeInterval: 0.2, target: self,   selector: #selector(self.btnStartProgessAction), userInfo: nil, repeats: true)
        // Do any additional setup after loading the view, typically from a nib.
       // myProgessView.progress = 0.0
       // LblProgressValue.text = "\(Int(myProgessView.progess*100))%"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnStartProgessAction(_ sender: Any) {
        self.ProgessView.progress += 0.01
        
        //set label for progess value
        self.LblProgessView.text = "\(Int(self.ProgessView.progress * 100))%"
        if self.ProgessView.progress >= 1 {
            self.progressTimer.invalidate()
        }
    }
    
    @IBAction func mySliderAction(_ sender: Any) {
        LblSliderValue.text = String(SliderValue.value)
    }
    
    @IBAction func myStepperAction(_ sender: Any) {
        LbStepperValue.text = String(myStepper.value)
    }
    
   @IBAction func btnStartAction(_ sender: Any) {
    activityIndicator.startAnimating()
    }
    
    
    @IBAction func btnStopAction(_ sender: Any) {
        activityIndicator.stopAnimating()
    }
    
    @IBAction func segmentChange(_ sender: Any) {
        print("selected : \(moodsSegment.selectedSegmentIndex)")
        
        imgMood.image = moodimages[moodsSegment.selectedSegmentIndex]
    }
}

